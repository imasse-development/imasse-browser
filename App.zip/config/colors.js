const colors = {
  primary: '#2a76dd',
  primaryHighlight: '#6ca0e8',
  separator: '#d9d9d9',
  bg_white: '#fff',
  bg_gray: '#f7f7f7',
  text_gray: '#494949',
  black: '#494949',
  blue: '#4495d4'
}

export default colors

